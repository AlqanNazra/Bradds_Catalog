import { useCallback } from 'react';
import { Link } from 'react-router-dom';
import { HeroBanner } from '../components/banner/HeroBanner';
import { CategoryNavigation } from '../components/category/CategoryNavigation';
import { CollectionSection } from '../components/collection/CollectionSection';
import { StateBlock } from '../components/common/StateBlock';
import { useAsync } from '../hooks/useAsync';
import { fetchCollections } from '../services/catalogApi';
import './HomePage.css';

/**
 * Homepage, top to bottom (mockup): hero banner → category strip → one section per
 * active collection (sorted by `Collection.sort_order`) → red CTA band.
 */
export function HomePage() {
  const load = useCallback(() => fetchCollections(), []);
  const { data, loading, error, reload } = useAsync(load, 'Gagal memuat koleksi.');

  const collections = data ?? [];

  return (
    <div className="home">
      <HeroBanner />
      <CategoryNavigation />

      <div className="home__body">
        {loading && <StateBlock variant="loading" title="Memuat koleksi…" />}

        {!loading && error && (
          <StateBlock
            variant="error"
            title="Koleksi tidak dapat dimuat"
            message={error}
            onRetry={reload}
          />
        )}

        {!loading && !error && collections.length === 0 && (
          <StateBlock
            variant="empty"
            title="Belum ada koleksi aktif"
            message="Koleksi aktif yang memiliki produk akan tampil di sini."
          />
        )}
      </div>

      {!loading &&
        !error &&
        collections.map((collection, index) => (
          <CollectionSection
            key={collection.id}
            collection={collection}
            highlight={index % 2 === 0 ? 'green' : 'yellow'}
          />
        ))}

      <section className="home__cta">
        <div className="home__cta-inner">
          <h2 className="home__cta-title">Temukan gaya berikutnya</h2>
          <p className="home__cta-text">
            Telusuri seluruh katalog Bradds, pilih warna dan ukuran, lalu lanjutkan pemesanan.
          </p>
          <Link to="/products" className="btn btn--primary">
            Lihat semua produk
          </Link>
        </div>
      </section>
    </div>
  );
}
