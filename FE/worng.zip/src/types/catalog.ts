/**
 * Domain types for the Bradds fashion catalog.
 *
 * These mirror the backend domain model 1:1. Wire DTOs stay snake_case because the
 * Go/Gin layer serialises structs with snake_case `json` tags (see ../go-gin-article),
 * and the API envelope is `{ "data": ... }`.
 */

/** Backend `Product.status` values (contract with the API). */
export const PRODUCT_STATUSES = ['ready', 'not_ready', 'discontinued'] as const;

export type ProductStatus = (typeof PRODUCT_STATUSES)[number];

export interface AdminUser {
  id: number;
  name: string;
  email: string;
  role: string;
  created_at: string;
  updated_at: string;
}

/** Category 1 ── N Product */
export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  image_url: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Color {
  id: number;
  name: string;
  hex_code: string;
  created_at: string;
  updated_at: string;
}

export interface Size {
  id: number;
  name: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

/** Product 1 ── N ProductImage */
export interface ProductImage {
  id: number;
  product_id: number;
  image_url: string;
  alt_text: string;
  sort_order: number;
  is_primary: boolean;
  created_at: string;
}

/**
 * Product 1 ── N ProductVariant, ProductVariant N ── 1 Color, N ── 1 Size.
 *
 * `color_id` / `size_id` are the source of truth. `color` / `size` are the preloaded
 * relations (GORM `Preload`) the API usually embeds; the service layer hydrates them
 * from the Color/Size collections when the backend only returns the foreign keys.
 */
export interface ProductVariant {
  id: number;
  product_id: number;
  color_id: number;
  size_id: number;
  sku: string;
  stock: number;
  price: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  color?: Color | null;
  size?: Size | null;
}

export interface Collection {
  id: number;
  name: string;
  slug: string;
  description: string;
  image_url: string;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

/** Product N ── M Collection (junction) */
export interface ProductCollection {
  product_id: number;
  collection_id: number;
}

export interface Product {
  id: number;
  category_id: number;
  name: string;
  slug: string;
  description: string;
  price: number;
  material: string;
  care_instruction: string;
  status: ProductStatus;
  created_at: string;
  updated_at: string;
  /** Preloaded relations — always present on API responses (empty array when none). */
  category: Category | null;
  images: ProductImage[];
  variants: ProductVariant[];
  collections: Collection[];
}

/** Banner is the domain equivalent of the admin UI concept "Main Board". */
export interface Banner {
  id: number;
  title: string;
  description: string;
  image_url: string;
  link_url: string;
  sort_order: number;
  is_active: boolean;
  start_at: string | null;
  end_at: string | null;
  created_at: string;
  updated_at: string;
}

/** Orderable product fields for the public listing pages. */
export const PRODUCT_SORTS = ['newest', 'name_asc', 'price_asc', 'price_desc'] as const;

export type ProductSort = (typeof PRODUCT_SORTS)[number];

/**
 * Query parameters accepted by `GET /api/products` (and `/api/admin/products`).
 * Sent as snake_case query params so the Gin handler can bind them directly.
 */
export interface ProductQuery {
  search?: string;
  category_id?: number | null;
  category_slug?: string | null;
  collection_id?: number | null;
  collection_slug?: string | null;
  status?: ProductStatus | null;
  sort?: ProductSort;
  page?: number;
  per_page?: number;
  /** Admin listings include non-active products. */
  include_inactive?: boolean;
}
