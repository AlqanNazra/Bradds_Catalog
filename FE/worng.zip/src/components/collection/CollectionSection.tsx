import { useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAsync } from '../../hooks/useAsync';
import { fetchCollectionProducts } from '../../services/catalogApi';
import type { Collection } from '../../types/catalog';
import { StateBlock } from '../common/StateBlock';
import { SmartImage } from '../common/SmartImage';
import { ProductGrid } from '../product/ProductGrid';
import './CollectionSection.css';

interface CollectionSectionProps {
  collection: Collection;
  perPage?: number;
  highlight?: 'green' | 'yellow';
}

/**
 * Homepage collection block: highlighted heading, an "Explore Now!" link and either the
 * collection's products (grid) or — when the collection has no products yet — a promo
 * tile built from the collection image (matches the mockup's promo cards).
 */
export function CollectionSection({
  collection,
  perPage = 4,
  highlight = 'green',
}: CollectionSectionProps) {
  const load = useCallback(
    () => fetchCollectionProducts(collection.slug, perPage),
    [collection.slug, perPage]
  );
  const { data, loading, error, reload } = useAsync(load, 'Gagal memuat koleksi.');

  const products = data?.data ?? [];
  const headingId = `collection-${collection.slug}`;

  return (
    <section className="collection-section" aria-labelledby={headingId}>
      <header className="collection-section__header">
        <h2 id={headingId} className="section-heading">
          <span
            className={`section-heading__mark${
              highlight === 'yellow' ? ' section-heading__mark--yellow' : ''
            }`}
            aria-hidden="true"
          />
          {collection.name}
        </h2>
        <Link to={`/collections/${collection.slug}`} className="collection-section__explore">
          Explore Now! →
        </Link>
      </header>

      {collection.description && (
        <p className="collection-section__description">{collection.description}</p>
      )}

      {loading && (
        <StateBlock
          variant="loading"
          title={`Memuat koleksi ${collection.name}…`}
          compact
        />
      )}

      {!loading && error && (
        <StateBlock
          variant="error"
          title="Koleksi tidak dapat dimuat"
          message={error}
          onRetry={reload}
          compact
        />
      )}

      {!loading && !error && products.length > 0 && <ProductGrid products={products} />}

      {!loading && !error && products.length === 0 && (
        <Link to={`/collections/${collection.slug}`} className="collection-section__promo">
          <span className="collection-section__promo-media">
            <SmartImage src={collection.image_url} alt={collection.name} />
          </span>
          <span className="collection-section__promo-body">
            <span className="collection-section__promo-title">{collection.name}</span>
            <span className="collection-section__promo-text">
              {collection.description || 'Belum ada produk pada koleksi ini.'}
            </span>
            <span className="collection-section__promo-link">Explore Now! →</span>
          </span>
        </Link>
      )}
    </section>
  );
}
