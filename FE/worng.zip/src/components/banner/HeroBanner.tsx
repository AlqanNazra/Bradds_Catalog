import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAsync } from '../../hooks/useAsync';
import { fetchBanners } from '../../services/catalogApi';
import { SmartImage } from '../common/SmartImage';
import './HeroBanner.css';

const ROTATE_MS = 7000;

/**
 * Homepage hero. Renders the active banners (sorted by `sort_order`) as a rotating
 * headline; a single banner renders without controls. The banner `link_url` may be an
 * internal path or an absolute URL.
 */
export function HeroBanner() {
  const load = useCallback(() => fetchBanners(), []);
  const { data, loading, error } = useAsync(load, 'Banner tidak dapat dimuat.');

  const banners = data ?? [];
  const [rotateIndex, setRotateIndex] = useState(0);

  // Derived (clamped) index — no effect needed when the banner list changes.
  const index = banners.length > 0 ? rotateIndex % banners.length : 0;

  useEffect(() => {
    if (banners.length <= 1) return;
    const timer = window.setInterval(() => {
      setRotateIndex((value) => value + 1);
    }, ROTATE_MS);
    return () => window.clearInterval(timer);
  }, [banners.length]);

  if (loading) {
    return <div className="hero-banner hero-banner--loading" aria-busy="true" />;
  }

  if (error || banners.length === 0) {
    return (
      <section className="hero-banner hero-banner--empty">
        <div className="hero-banner__placeholder">
          <p className="hero-banner__placeholder-title">
            {error ? 'Banner belum dapat dimuat' : 'Belum ada banner aktif'}
          </p>
          <p className="hero-banner__placeholder-text">
            {error
              ? 'Coba muat ulang halaman ini.'
              : 'Tambahkan banner dari menu Edit Main Board pada panel admin.'}
          </p>
        </div>
      </section>
    );
  }

  const active = banners[index];
  const hasLink = Boolean(active.link_url);

  return (
    <section className="hero-banner">
      <div className="hero-banner__media">
        <SmartImage src={active.image_url} alt={active.title} eager placeholderLabel="Gambar banner" />
      </div>

      <div className="hero-banner__overlay">
        <h1 className="hero-banner__title">{active.title}</h1>
        {active.description && <p className="hero-banner__description">{active.description}</p>}
        {hasLink &&
          (active.link_url.startsWith('/') ? (
            <Link to={active.link_url} className="btn btn--primary">
              Lihat koleksi
            </Link>
          ) : (
            <a href={active.link_url} className="btn btn--primary" rel="noreferrer noopener">
              Lihat koleksi
            </a>
          ))}
      </div>

      {banners.length > 1 && (
        <div className="hero-banner__dots" role="tablist" aria-label="Pilih banner">
          {banners.map((banner, dotIndex) => (
            <button
              key={banner.id}
              type="button"
              role="tab"
              aria-selected={dotIndex === index}
              aria-label={`Banner ${dotIndex + 1}: ${banner.title}`}
              className={`hero-banner__dot${dotIndex === index ? ' hero-banner__dot--active' : ''}`}
              onClick={() => setRotateIndex(dotIndex)}
            />
          ))}
        </div>
      )}
    </section>
  );
}
